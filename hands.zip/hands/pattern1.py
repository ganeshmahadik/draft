import json
with open("data/example.json","rt") as f:
	obj =json.load(f)
	
print(obj)
print(type(obj))

el=[]

for emp in obj:
	el.append( emp['empId'])

print(el)

# el=set()
# for fname in obj:
	
	# for ph in emp['details']['phoneNumbers']:
		# if ph['type']=='office'and emp['details']['isAlive']==True:
			# el.add(ph['number'])
			
el=[]
for fname in obj:
	
	for ph in emp['details']['phoneNumbers']:
		if ph['type']=='office'and emp['details']['isAlive']==True:
			el.append(ph['number'])
print(el)

# Names taking
el=[]
for fname1 in obj:
	el.append(emp['details']['firstName'] +" "+ emp['details']['lastName'])
	
	
print(el)


import glob
print(glob.glob("data/*"))

import csv
#f=open("data/iris.csv","rt") #read and text
#lines = f.readline()
#f.close()

#or
with open("data/iris.csv","rt") as f:
	rd= csv.reader(f)
	rows =list(rd)

for r in rows: print( r) #adding result to new lines

header=rows[0]
rows=rows[1:]
rowsd=[]

for sl,sw,pl,pw,n in rows : # breaking elements 
	rowsd.append([float(sl),float(sw),float(pl),float(pw),n]) #converting into float


for r in rowsd: print( r) #adding result to new line
	
print(len(rowsd))

 name

un=set()
for sl,sw,pl,pw,n in rowsd :
	un.add(n)

print(un) # {'Iris-virginica', 'Iris-versicolor', 'Iris-setosa'}
#or
#un={r-[-1] for r in rowsd}

ed={}
for n in un :
	el = []
	for sl,sw,pl,pw,name in rowsd:
		if n == name:
			el.append(sl)
	ed[n] = {'max': max(el), 'sum': sum(el),'min':min(el)} #min records
print(ed)
	


