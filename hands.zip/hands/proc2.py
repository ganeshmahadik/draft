import multiprocessing, time
#shared=[]

def proc(lck,shared):
	#global shared
	print("before",multiprocessing.current_process().name)
	with lck: #Accquired
		print("Accquired", multiprocessing.current_process().name)
		time.sleep(2)
		shared.value+=1 
		#shared.append(multiprocessing.current_process().getName())
	#released here
	time.sleep(2)
	
if __name__=='__main__':
	ids=[]
	
	shared=multiprocessing.Value('i',0,lock=False) #one at a time
	lock=multiprocessing.RLock() # two
	for i in range(10):
		t=multiprocessing.Process(target=proc,args=(lock,shared))
		ids.append(t)
	[t.start() for t in ids]
	[t.join() for t in ids]