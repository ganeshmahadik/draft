import sys

#a= sys.argv[1]
#b= sys.argv[2]
#c= int(a) + int(b)
#print("a=",a,"b=",b,"c=",c)

a=1
print(type(a))
f=1.2
b=True
v="Hello"
rs=r"Hello"
s='Hello'
s="""Hello
world"""

if a >=1:
	print(a)
elif a< 1:
	print(a)
else:
	print(a)

#######################

s="OK"
lst=[1,2,3]
set1={1,2,3}
d={'ok':1,'nok':2}

#Length
print(len(s),len(lst),len(set1),len(d))

#Empty

es="" #immutable
el=[] #immutable, duplicate allowed, inserction ordered
es=set() #mutable, Opposite of list, No order, no duplicates 
ed={} #mutable
et=() #immutable

#type
print(type(es),type(el),type(es),type(ed),type(et))
# str, list, set, dict, tuple

#membership checking
"0" in s # True
"0" not in s # True
1 in lst # does 1 exist in list
1 in set1
"ok" in d # Does key ok exist in d

#comparison
#s=="OK", s!="NOK"
lst==[1,2]
(1,2)==(2,1)
{1,1,1,2,3}== {1,2,3} # True

#Iteration,
s="OK"
for e in s:
	print(e)
for e in lst:
	print(e)
for e in set1:
	print(e)
for k in d: #d ={ 'ok' : 1, 'nok': 2 }
	print(k,d[k])

#################

#Accessing

lst=[1,2,3,4]
s="Hello"
lst[0],s[0] # (1, 'H')
lst[-1],s[-1] #(4, 'o')
lst[-4],s[-5] #(1,'H')
#Slicing
lst[0:4:1] #start:end:step [ 1,2,3,4]
lst[:], s[:] #([1,2,3,4],'Hello')
lst[::-1],s[::-1] #([4,3,2,1,),'olleH')
s[::2],s[::2] # ('Hlo','Hlo')
set1={1,2,3}
#set1[0] #Error

#Adding
lst.append(20) 
set1.add(20)

#dict
d={'ok':1,'nok':2}
d['ok'] #1
d['new']=20 # Adding new key 
d['ok']=20 #Updating
d.keys() #all keys
d.values() #all Values
print(d.items())


#Map pattern
#Inout list, output list
lst=[3,5,2,4]
el=[]
for e in lst:
	el.append(e*e)
print(el) #Squaring each elements

#Or

el=[ e*e for e in lst] #future
#with filters
el=[]
#for e in lst:
#	if e%2==0:
#	el.append(e*e)
#print(el) #Squaring only even

#Input= List, Outpur=set
es=set()
for e in lst:
	es.add(e*e)
#Or
es= {e*e for e in lst}

#inout =list, output=dict
ed={}
for e in lst:
	ed[e]=e*e
#Or
ed={e: e*e for e in lst}

#
list(enumerate(['a','b'])) #[(0, 'a'), (1, 'b')]
list(zip(['a','b'],[10,20])) #[('a', 10), ('b', 20)]
lst=list(zip(['a','b'],[10,20]))
list(enumerate(['a','b'])) #[(0, 'a'), (1, 'b')]
list(zip(['a','b'],[10,20])) #[('a', 10), ('b', 20)]

lst=list(zip(['a','b'],[10,20]))
for e in lst:
	print(e[-1])

#10
#20
print(lst)
[('a', 10), ('b', 20)]


#Writechecksum

input="ABCDEF1234567890"
el=[]
for f,s in zip(input[::2],input[1::2]):
	el.append(int(f+s, base=16))
sum(el) %255

#Or
sum([int(f+s, base=16) for f,s in zip (input[::2],input[1::2]) ]) % 255

#functions

def add(x,y):
	return x+y

add(1,2) #Positionak arg passing
add(y=3,x=2) #Keyword basedargs passing
add(2,y=3) # mix, restrictions : Positional comes first

def add2(x,y=20):
	return x+y

add2(2) #22
add2(2,30) #32

#Parallel assignment

a,b=1,2
a,b=b,a # 2,1

a, *b, c= 1, 2, 3, 4 # (1,[2,3],4)
def add3(*args):
	s=0
	for e in args:
		s +=e
	return s 

add3() # 0
add3(1,2,3,4,) #10
lst=[1, 2, 3, 4]
add3(lst[0],lst[1],lst[2],lst[3]) #10
#or 
add3(*lst) #10

#LGB scope 

#dont use built in names

def p(x):
	print(x+y)
	
y=20
p(2)


#import random
#el=[]
f#or i

#Sorting

d={'use':1,'india':10}
d #{'use': 1, 'india': 10}
d={'use':1,'india':10}
sorted(d) #['india', 'use']
def p(k):
...     return d[k]
...
sorted(d,key=lambda k: d[k]) #['use', 'india']






















