import numpy as np
x=np.array([1,2,3]) #array([1, 2, 3])
y=np.linspace(2.0,3.0,num=3) # array([ 2. ,  2.5,  3. ])
z=np.arange(12).reshape(2,6) # array([[ 0,  1,  2,  3,  4,  5],
									#[ 6,  7,  8,  9, 10, 11]])
ru=np.random.random((2,6)) #array([[ 0.02573992,  0.93173557,  0.3968328 ,  0.71794799,  0.76298192,
									#0.60456903],
									#[ 0.08088703,  0.20579055,  0.86554962,  0.74667598,  0.62451953,
									#0.35023919]])
rn=np.random.normal(0,1,(6,4))  # array([[ 0.54321545,  0.36445265, -0.23432639,  0.38661356],
								# [ 0.90936254,  0.65589152, -1.70331318,  0.77644155],
								# [ 0.36866518,  0.09259653, -0.99708912,  0.06761597],
								# [ 0.76972877,  0.89389845, -1.18432486, -2.33773523],
								# [-1.23722451, -0.26647785, -1.06646053, -1.36823903],
								# [ 1.12809227, -1.24719098,  1.09994711, -0.55177872]])

#Shape
x.shape, rn.shape # ((3,),(6,4))
x.ndim, rn.ndim #(1,2)

#Access
x[0] # 1
z[0,0] # 0
z[:,0:2] #array([[0,1],
				#[6,7]]) mu, sigma
#z[0,2,:]
z[z>2]
z[(z>2) & (z<4)]
z[0,0]=20

#OPeration
x*y
x+y 
x-y 
np.log(x)
np.sin(y)
rn *2 +3

#Matrix mul
np.dot(ru,rn)

print(np.sum(z,axis=0)) #Column wise array([ 6,  8, 10, 12, 14, 16])
print(np.sum(z,axis=1)) #rowwise array([ 6,  8, 10, 12, 14, 16])

print(np.sort(z,axis=0))
print(np.sort(z,axis=1))

np.insert(z,2,10, axis=0)
print(z)
np.insert(z,2,[1,2,3,4,5,6],axis=0)
print(z)


import pandas as pd
iris=pd.read_csv("data/iris.csv")
iris.columns
#Index(['SepalLength', 'SepalWidth', 'PetalLength', 'PetalWidth', 'Name'], dtype='object')
iris.index
#RangeIndex(start=0, stop=150, step=1)
iris.dtypes
#SepalLength    float64
#SepalWidth     float64
#PetalLength    float64
#PetalWidth     float64
#Name            object
#dtype: object
iris.head()
 #  SepalLength  SepalWidth  PetalLength  PetalWidth         Name
 #0          5.1         3.5          1.4         0.2  Iris-setosa
 #1         4.9         3.0          1.4         0.2  Iris-setosa
 #2          4.7         3.2          1.3         0.2  Iris-setosa
 #3          4.6         3.1          1.5         0.2  Iris-setosa
 #4          5.0         3.6          1.4         0.2  Iris-setosa

iris.tail()
#     SepalLength  SepalWidth  PetalLength  PetalWidth            Name
#145          6.7         3.0          5.2         2.3  Iris-virginica
#146          6.3         2.5          5.0         1.9  Iris-virginica
#147          6.5         3.0          5.2         2.0  Iris-virginica
#148          6.2         3.4          5.4         2.3  Iris-virginica
#149          5.9         3.0          5.1         1.8  Iris-virginica
 
#access

iris.SepalLength
iris['SepalLength']
iris[['SepalLength','PetalLength']]
sorted(iris)

#number based
iris.iloc[0:10,0]
iris.iloc[0:10,[0,1]]

#lable based
iris.loc[0:10, 'SepalLength']
iris.loc[0:10,['SepalLength','PetalLength']] 
iris.loc[iris.Name == 'Iris-setosa',['SepalLength','PetalLength']]

#new column
iris_m=iris.copy()
iris_m['SepalRatio']=iris_m.SepalWidth/iris_m.SepalLength
iris_m['PetalRatio']=iris_m.PetalWidth/iris_m.PetalLength
iris_m.head()

import matplotlib.pyplot as plt

iris_m.plot(kind='scatter',x='SepalRatio',y='PetalRatio')
#plt.show()


#cluster center
features = iris_m[['SepalRatio','PetalRatio']]
from sklearn.cluster import *
kmeans = KMeans(n_clusters=2, random_state=0).fit(features)
kmeans.cluster_centers_
kmeans.labels_

#write to csv
#2*iris.SepalLength + 3
iris.groupby('Name').agg({'SepalLength':['min','max'], 'PetalLength':'count'}).to_csv("processed.csv")

print(iris.groupby('Name').agg({'SepalLength':['min','max'], 'PetalLength':'count'}).head())



#Exception
class MyException(Exception):
	pass

def f():
	raise Exception("some error")

try:
	f()
	
except Exception as ex:
	print(ex)
finally:
	print("always")







# django-admin startproject first

# cd  first

# mkdir static

python manage.py migrate

python manage.py runserver 8000

http://localhost:8000/static/hello.html






