import time, threading

def w(sleeptime):
	time.sleep(sleeptime)
	print(threading.current_thread().getName(),"finished")
	
#w(10) MainThead Finished
	
if __name__=='__main__':
	t=threading.Thread(target=w,args=(10,))
	t.start()
	t.join()
	
#t=threading.Thread(target=w,args=(10,))
#t.start();print("Hello" # first hello will be printed

#t=threading.Thread(target=w,args=(10,))
#t.start();t.join();print("Hello")
#Thread-3 finished
#Hello