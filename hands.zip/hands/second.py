import pkg.mex

print(pkg.mex.square(10))

from pkg.mex import square 

#1
from pkg import square
#2
from pkg import *
print(square(10))
#3
from pkg import cube
print(cube(10))