import threading, time
import requests,concurrent.futures

def download(url):
	print(threading.current_thread().getName(),url)
	con=requests.get(url)
	return [url,len(con.text)]

	
if __name__=='__main__':
	urls=[ "http://www.google.co.in" for _ in range(10)]
	st=time.time()
	print("sequential")
	r=download(urls[0])
	one=time.time() - st
	print(r, " took",one," secs")
	print("now parallel")
	#to use with multiprocessing, use ProcessPoolExecutor
	ex=concurrent.futures.ThreadPoolExecutor(max_workers=10)
	st=time.time()
	rs=ex.map(download,urls)
	print(list(rs),"took",time.time() -st,"suppose to take",one*10," sec if you do sequentially")
	ex.shutdown()


	
lst=[1,2,3]
g=[e*e for e in lst]
g
#[1, 4, 9]
g2=(e*e for e in lst)
g2
#<generator object <genexpr> at 0x000001BF109289E8>
list(g2)
#[1, 4, 9]
g2=(e*e for e in lst)
i=iter(g2)
next(i)
#1
next(i)
#4
next(i)
#9
#next(i)
#Traceback (most recent call last):
#  File "<stdin>", line 1, in <module>
#StopIteration
g2=(e*e for e in lst)
for e in g2:
	print(e)
    
#1
#4
#9
def fib():
		a,b=0,1
		while True:
				yield a
				a,b=b,a+b
    
#for e in fib():
		#print(e)
#print

#Iterators
def fib():
	a,b=0,1
	while True:
			yield a
			a,b=b,a+b
			
i=iter(fib())
import itertools
itertools.islice(i,10)
x=list(itertools.islice(i,2000))
print(len(str(list(itertools.islice(i,2000))[0])))
#print(x)
			
			
			