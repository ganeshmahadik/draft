import re
# s1="Hello World"
# sp=r"\w+"
# re.findall(sp,s1) #['Hello', 'World']
# re.findall(r"Hello\s(\w+),s1) # ['World']
# d="2019-12-12"
# sp=r"\d\d\d\d-\d\d-\d\d"
# re.findall(sp,d) #['2019-12-12']
# re.findall(r"\w\w","ABCD") # [ 'AB','CD']
# re.findall(r"(?=\w\w))","ABCD") # ['AB','BC','CD']
# s2="A,B:C;D"
# s2.split(",") # ['A','B:C:D']
# s2.split(e",|:|;",s2) # [ 'A','B','C','D']
# re.sub("World", "Earth",s1) # 'Hello Earth'
# s4="The world world is round round"
# re.sub(r"(\w+)\s+\1",r"\1", s4) # 'The world is round'

import subprocess as S
command = ''
proc=S.Popen(command,shell=True,stdout=S.PIPE,stderr=S.STDOUT,universal_newlines=True)
out,err=proc.communicate()
out[0:10]
#\nHost Name
print(out)

hots=re.findall(r"KB([\w-]+)",out)

print(hots)

#http automation

import requests as r
res = r.get("http://httpbin.org/get")
res.json()
print(res.text)


import json
with open("data/example.json","rt") as f:
	obj =json.load(f)
	
print(obj)
print(type(obj))

el=[]

for emp in obj:
	el.append(emp['empId'])

print(el)
#Or
#el=[emp['empId'] for emp in obj]


el=[]
for fname in obj:
	el.append(emp['details']['firstName'] + emp['details']['lastName'])
		
	
print(el)


el=[]
for fname in obj:
	
	for ph in emp['details']['phoneNumbers']:
		if ph['type']=='office'and emp['details']['isAlive']==True:
			el.append(ph['number'])
			
print(el)

import xml.etree.ElementTree as ET

tr=ET.parse("data/example.xml")
r = tr.getroot()
print (r.tag)
print(r.attrib)
print(r.text)
xp="./country/rank"
nn=r.findall(xp)
print(nn)
rl=[]
for n in nn:
	rl.append(int(n.text))

print(rl)
#[int(n.text) for n in nn]
















