import threading, time
shared=[]

def proc(lck):
	global shared
	print("before",threading.current_thread().getName())
	with lck: #Accquired
		print("Accquired", threading.current_thread().getName())
		time.sleep(2)
		shared.append(threading.current_thread().getName())
	#released here
	time.sleep(2)
	
if __name__=='__main__':
	ids=[]
	
	lock=threading.RLock() #one at a time
	#lock=threading.Semaphore(2) # two
	for i in range(10):
		t=threading.Thread(target=proc,args=(lock,))
		ids.append(t)
	[t.start() for t in ids]
	[t.join() for t in ids]
	
