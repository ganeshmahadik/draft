from pkg.MyInt import MyInt
import pytest

class TestMyInt:
	def test_add(self):
		a=MyInt(2)
		b=MyInt(3)
		assert a+b == MyInt(5)

	def test_square(self):
		a=MyInt(3)
		assert a.square() ==9
	
	def test_str(self):
		a=MyInt(3)
		assert a.val == 3

#py.test -v my_test.py
#pip install pytest-cov
#py.test --cov=pkg/ -v my_test.py


