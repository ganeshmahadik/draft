#1

from .mex import square

#2
__all__=['square']

#3
def cube(x):
	return square(x)*x

#4 (not so std)
__version__='0.1'
__author__='Name'
