class MyInt:
	def __init__(self,v):
		self.val=v
	def __add__(self,other): 
		z=self.val + other.val
		return MyInt(z)
	def __str__(self): 
		return "MyInt(%d)" % (self.val,)
	def __eq__(self,other):
		return self.val == other.val
	def square(self):
		return self.val * self.val

#from pkg.MyInt import MyInt
#a= MyInt(2)
#b= MyInt(3)
#a.add(b)
#5
#print(a)
#MyInt(2)

# from pkg.MyInt import MyInt
# b= MyInt(3)
# a= MyInt(2)
# c = a + b
# print(c)
# MyInt(5)
#c2 = 3 +3 +4
#print(c2)
#10