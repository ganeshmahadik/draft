def square(x):
	z=x*x
	return z