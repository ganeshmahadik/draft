import glob
print(glob.glob("data/*"))

import csv
#f=open("data/iris.csv","rt") #read and text
#lines = f.readline()
#f.close()

#or
with open("data/iris.csv","rt") as f:
	rd= csv.reader(f)
	rows =list(rd)
print(rows)

header=rows[0]
rows=rows[1:]
rowsd=[]


for sl,sw,pl,pw,n in rows :
	rowsd.append([float(sl),float(sw),float(pl),float(pw),n]) #converting into float

rowsd[0:5]
#print(rowsd)

print(len(rowsd))

#unique name

un=set()
for sl,sw,pl,pw,n in rowsd :
	un.add(n)

print(un) # {'Iris-virginica', 'Iris-versicolor', 'Iris-setosa'}
#or
#un={r-[-1] for r in rowsd}

ed={}
for n in un :
	el = []
	for sl,sw,pl,pw,name in rowsd:
		if n == name:
			el.append(sl)
	ed[n] = {'max': max(el), 'sum': sum(el),'min':min(el)} #min records
print(ed) # 'Iris-setosa': {'min': 4.3, 'sum': 250.29999999999998, 'max': 5.8},
print(ed['Iris-setosa']['min'])


ed={}
for n in un :
	edd = {}
	for i,fe in enumerate(header[:-1]):
		el=[]
		for r in rowsd:
			if r[-1] == n:
				el.append(r[i])
		edd[fe] = {'max': max(el), 'sum': sum(el),'min':min(el)} #min records
	ed[n]=edd
#print(ed)

from sqlite3 import connect
con=connect("iris.db")
cur=con.cursor()
con.execute("""
create table if not exists iris (sl double,sw double, pl double, pw double, name string)
""")
for r in rowsd:
	con.execute("insert into iris values(?,?,?,?,?)",r)
con.commit()
r=con.execute("select name,Max(sl) from iris group by name")
result=list(r.fetchall())

print(result)


